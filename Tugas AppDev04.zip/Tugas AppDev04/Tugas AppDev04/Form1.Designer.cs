﻿namespace Tugas_AppDev04
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_teamlist = new System.Windows.Forms.Label();
            this.lbl_country = new System.Windows.Forms.Label();
            this.lbl_team = new System.Windows.Forms.Label();
            this.combo_country = new System.Windows.Forms.ComboBox();
            this.lbl_teamname = new System.Windows.Forms.Label();
            this.lbl_teamcountry = new System.Windows.Forms.Label();
            this.lbl_city = new System.Windows.Forms.Label();
            this.txt_teamname = new System.Windows.Forms.TextBox();
            this.txt_country = new System.Windows.Forms.TextBox();
            this.txt_city = new System.Windows.Forms.TextBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.lbl_adding = new System.Windows.Forms.Label();
            this.lbl_player = new System.Windows.Forms.Label();
            this.lbl_playname = new System.Windows.Forms.Label();
            this.lbl_playnumber = new System.Windows.Forms.Label();
            this.lbl_playposition = new System.Windows.Forms.Label();
            this.txt_pemain = new System.Windows.Forms.TextBox();
            this.txt_nomor = new System.Windows.Forms.TextBox();
            this.btn_add2 = new System.Windows.Forms.Button();
            this.lbx_player = new System.Windows.Forms.ListBox();
            this.btn_clear = new System.Windows.Forms.Button();
            this.pnl_team = new System.Windows.Forms.Panel();
            this.combo_team = new System.Windows.Forms.ComboBox();
            this.pnl_posisi = new System.Windows.Forms.Panel();
            this.combo_posisi = new System.Windows.Forms.ComboBox();
            this.pnl_team.SuspendLayout();
            this.pnl_posisi.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_teamlist
            // 
            this.lbl_teamlist.AutoSize = true;
            this.lbl_teamlist.Location = new System.Drawing.Point(27, 55);
            this.lbl_teamlist.Name = "lbl_teamlist";
            this.lbl_teamlist.Size = new System.Drawing.Size(92, 13);
            this.lbl_teamlist.TabIndex = 0;
            this.lbl_teamlist.Text = "Team Soccer list :";
            // 
            // lbl_country
            // 
            this.lbl_country.AutoSize = true;
            this.lbl_country.Location = new System.Drawing.Point(31, 96);
            this.lbl_country.Name = "lbl_country";
            this.lbl_country.Size = new System.Drawing.Size(88, 13);
            this.lbl_country.TabIndex = 1;
            this.lbl_country.Text = "Choose Country :";
            // 
            // lbl_team
            // 
            this.lbl_team.AutoSize = true;
            this.lbl_team.Location = new System.Drawing.Point(31, 137);
            this.lbl_team.Name = "lbl_team";
            this.lbl_team.Size = new System.Drawing.Size(79, 13);
            this.lbl_team.TabIndex = 2;
            this.lbl_team.Text = "Choose Team :";
            // 
            // combo_country
            // 
            this.combo_country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_country.FormattingEnabled = true;
            this.combo_country.Location = new System.Drawing.Point(135, 93);
            this.combo_country.Name = "combo_country";
            this.combo_country.Size = new System.Drawing.Size(123, 21);
            this.combo_country.TabIndex = 3;
            this.combo_country.SelectedIndexChanged += new System.EventHandler(this.combo_country_SelectedIndexChanged);
            this.combo_country.Click += new System.EventHandler(this.combo_country_Click);
            // 
            // lbl_teamname
            // 
            this.lbl_teamname.AutoSize = true;
            this.lbl_teamname.Location = new System.Drawing.Point(298, 93);
            this.lbl_teamname.Name = "lbl_teamname";
            this.lbl_teamname.Size = new System.Drawing.Size(71, 13);
            this.lbl_teamname.TabIndex = 6;
            this.lbl_teamname.Text = "Team Name :";
            // 
            // lbl_teamcountry
            // 
            this.lbl_teamcountry.AutoSize = true;
            this.lbl_teamcountry.Location = new System.Drawing.Point(298, 134);
            this.lbl_teamcountry.Name = "lbl_teamcountry";
            this.lbl_teamcountry.Size = new System.Drawing.Size(79, 13);
            this.lbl_teamcountry.TabIndex = 7;
            this.lbl_teamcountry.Text = "Team Country :";
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Location = new System.Drawing.Point(298, 171);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(60, 13);
            this.lbl_city.TabIndex = 8;
            this.lbl_city.Text = "Team City :";
            // 
            // txt_teamname
            // 
            this.txt_teamname.Location = new System.Drawing.Point(388, 90);
            this.txt_teamname.Name = "txt_teamname";
            this.txt_teamname.Size = new System.Drawing.Size(100, 20);
            this.txt_teamname.TabIndex = 9;
            // 
            // txt_country
            // 
            this.txt_country.Location = new System.Drawing.Point(388, 130);
            this.txt_country.Name = "txt_country";
            this.txt_country.Size = new System.Drawing.Size(100, 20);
            this.txt_country.TabIndex = 10;
            // 
            // txt_city
            // 
            this.txt_city.Location = new System.Drawing.Point(388, 171);
            this.txt_city.Name = "txt_city";
            this.txt_city.Size = new System.Drawing.Size(100, 20);
            this.txt_city.TabIndex = 11;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(388, 206);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(46, 23);
            this.btn_add.TabIndex = 12;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // lbl_adding
            // 
            this.lbl_adding.AutoSize = true;
            this.lbl_adding.Location = new System.Drawing.Point(298, 55);
            this.lbl_adding.Name = "lbl_adding";
            this.lbl_adding.Size = new System.Drawing.Size(76, 13);
            this.lbl_adding.TabIndex = 5;
            this.lbl_adding.Text = "Adding Team :";
            // 
            // lbl_player
            // 
            this.lbl_player.AutoSize = true;
            this.lbl_player.Location = new System.Drawing.Point(516, 55);
            this.lbl_player.Name = "lbl_player";
            this.lbl_player.Size = new System.Drawing.Size(78, 13);
            this.lbl_player.TabIndex = 13;
            this.lbl_player.Text = "Adding Player :";
            // 
            // lbl_playname
            // 
            this.lbl_playname.AutoSize = true;
            this.lbl_playname.Location = new System.Drawing.Point(516, 90);
            this.lbl_playname.Name = "lbl_playname";
            this.lbl_playname.Size = new System.Drawing.Size(73, 13);
            this.lbl_playname.TabIndex = 14;
            this.lbl_playname.Text = "Player Name :";
            // 
            // lbl_playnumber
            // 
            this.lbl_playnumber.AutoSize = true;
            this.lbl_playnumber.Location = new System.Drawing.Point(516, 130);
            this.lbl_playnumber.Name = "lbl_playnumber";
            this.lbl_playnumber.Size = new System.Drawing.Size(82, 13);
            this.lbl_playnumber.TabIndex = 15;
            this.lbl_playnumber.Text = "Player Number :";
            // 
            // lbl_playposition
            // 
            this.lbl_playposition.AutoSize = true;
            this.lbl_playposition.Location = new System.Drawing.Point(516, 174);
            this.lbl_playposition.Name = "lbl_playposition";
            this.lbl_playposition.Size = new System.Drawing.Size(82, 13);
            this.lbl_playposition.TabIndex = 16;
            this.lbl_playposition.Text = "Player Position :";
            // 
            // txt_pemain
            // 
            this.txt_pemain.Location = new System.Drawing.Point(612, 90);
            this.txt_pemain.Name = "txt_pemain";
            this.txt_pemain.Size = new System.Drawing.Size(100, 20);
            this.txt_pemain.TabIndex = 17;
            // 
            // txt_nomor
            // 
            this.txt_nomor.Location = new System.Drawing.Point(612, 130);
            this.txt_nomor.Name = "txt_nomor";
            this.txt_nomor.Size = new System.Drawing.Size(100, 20);
            this.txt_nomor.TabIndex = 18;
            // 
            // btn_add2
            // 
            this.btn_add2.Location = new System.Drawing.Point(612, 206);
            this.btn_add2.Name = "btn_add2";
            this.btn_add2.Size = new System.Drawing.Size(46, 23);
            this.btn_add2.TabIndex = 20;
            this.btn_add2.Text = "Add";
            this.btn_add2.UseVisualStyleBackColor = true;
            this.btn_add2.Click += new System.EventHandler(this.btn_add2_Click);
            // 
            // lbx_player
            // 
            this.lbx_player.FormattingEnabled = true;
            this.lbx_player.Location = new System.Drawing.Point(34, 174);
            this.lbx_player.Name = "lbx_player";
            this.lbx_player.Size = new System.Drawing.Size(223, 134);
            this.lbx_player.TabIndex = 21;
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(34, 316);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(64, 23);
            this.btn_clear.TabIndex = 22;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // pnl_team
            // 
            this.pnl_team.Controls.Add(this.combo_team);
            this.pnl_team.Location = new System.Drawing.Point(136, 127);
            this.pnl_team.Name = "pnl_team";
            this.pnl_team.Size = new System.Drawing.Size(121, 44);
            this.pnl_team.TabIndex = 23;
            // 
            // combo_team
            // 
            this.combo_team.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_team.FormattingEnabled = true;
            this.combo_team.Location = new System.Drawing.Point(0, 10);
            this.combo_team.Name = "combo_team";
            this.combo_team.Size = new System.Drawing.Size(121, 21);
            this.combo_team.TabIndex = 0;
            this.combo_team.SelectedIndexChanged += new System.EventHandler(this.combo_team_SelectedIndexChanged);
            // 
            // pnl_posisi
            // 
            this.pnl_posisi.Controls.Add(this.combo_posisi);
            this.pnl_posisi.Location = new System.Drawing.Point(600, 156);
            this.pnl_posisi.Name = "pnl_posisi";
            this.pnl_posisi.Size = new System.Drawing.Size(111, 34);
            this.pnl_posisi.TabIndex = 24;
            // 
            // combo_posisi
            // 
            this.combo_posisi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_posisi.FormattingEnabled = true;
            this.combo_posisi.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.combo_posisi.Location = new System.Drawing.Point(11, 10);
            this.combo_posisi.Name = "combo_posisi";
            this.combo_posisi.Size = new System.Drawing.Size(100, 21);
            this.combo_posisi.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(724, 351);
            this.Controls.Add(this.pnl_posisi);
            this.Controls.Add(this.pnl_team);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.lbx_player);
            this.Controls.Add(this.btn_add2);
            this.Controls.Add(this.txt_nomor);
            this.Controls.Add(this.txt_pemain);
            this.Controls.Add(this.lbl_playposition);
            this.Controls.Add(this.lbl_playnumber);
            this.Controls.Add(this.lbl_playname);
            this.Controls.Add(this.lbl_player);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.txt_city);
            this.Controls.Add(this.txt_country);
            this.Controls.Add(this.txt_teamname);
            this.Controls.Add(this.lbl_city);
            this.Controls.Add(this.lbl_teamcountry);
            this.Controls.Add(this.lbl_teamname);
            this.Controls.Add(this.lbl_adding);
            this.Controls.Add(this.combo_country);
            this.Controls.Add(this.lbl_team);
            this.Controls.Add(this.lbl_country);
            this.Controls.Add(this.lbl_teamlist);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnl_team.ResumeLayout(false);
            this.pnl_posisi.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_teamlist;
        private System.Windows.Forms.Label lbl_country;
        private System.Windows.Forms.Label lbl_team;
        private System.Windows.Forms.ComboBox combo_country;
   
        private System.Windows.Forms.Label lbl_teamname;
        private System.Windows.Forms.Label lbl_teamcountry;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.TextBox txt_teamname;
        private System.Windows.Forms.TextBox txt_country;
        private System.Windows.Forms.TextBox txt_city;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Label lbl_adding;
        private System.Windows.Forms.Label lbl_player;
        private System.Windows.Forms.Label lbl_playname;
        private System.Windows.Forms.Label lbl_playnumber;
        private System.Windows.Forms.Label lbl_playposition;
        private System.Windows.Forms.TextBox txt_pemain;
        private System.Windows.Forms.TextBox txt_nomor;
        private System.Windows.Forms.Button btn_add2;
        private System.Windows.Forms.ListBox lbx_player;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Panel pnl_team;
        private System.Windows.Forms.ComboBox combo_team;
        private System.Windows.Forms.Panel pnl_posisi;
        private System.Windows.Forms.ComboBox combo_posisi;
    }
}

