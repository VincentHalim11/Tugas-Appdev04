﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tugas_AppDev04
{
    public partial class Form1 : Form
    {
        DataTable sepakbola = new DataTable();
        bool cek_No = false;
        bool cek_Team = false;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sepakbola.Columns.Add("Negara");
            sepakbola.Columns.Add("Team");
            sepakbola.Columns.Add("Nomor");
            sepakbola.Columns.Add("Nama");
            sepakbola.Columns.Add("Posisi");
            sepakbola.Rows.Add("Japan", "Tokyo Fc", "01", "Tsuyosi Kodama", "GK");
            sepakbola.Rows.Add("Japan", "Tokyo Fc", "02", "Hokata Nakamura", "DF");
            sepakbola.Rows.Add("Japan", "Tokyo Fc", "04", "Yasuki Kimoto", "FW");
            sepakbola.Rows.Add("Japan", "Tokyo Fc", "05", "Yuto Nagamoto", "DF");
            sepakbola.Rows.Add("Japan", "Tokyo Fc", "07", "Manato Shinada", "MF");
            sepakbola.Rows.Add("Japan", "Tokyo Fc", "08", "Takahiro Ko", "DF");
            sepakbola.Rows.Add("Japan", "Tokyo Fc", "13", "Go Hotano", "GK");
            sepakbola.Rows.Add("Japan", "Tokyo Fc", "30", "Teppei Oka", "FW");
            sepakbola.Rows.Add("Japan", "Tokyo Fc", "32", "Kanta Doi", "FW");
            sepakbola.Rows.Add("Japan", "Tokyo Fc", "37", "Kei Koizumi", "MF");
            sepakbola.Rows.Add("Japan", "Tokyo Fc", "40", "Riki Harakawa", "MF");
            sepakbola.Rows.Add("Japan", "Blue Lock Eleven", "01", "Gin Gagamaru", "GK");
            sepakbola.Rows.Add("Japan", "Blue Lock Eleven", "02", "Jyubei Aryu", "FW");
            sepakbola.Rows.Add("Japan", "Blue Lock Eleven", "03", "Ikki Niko", "FW");
            sepakbola.Rows.Add("Japan", "Blue Lock Eleven", "04", "Hyoma Chigiri", "FW");
            sepakbola.Rows.Add("Japan", "Blue Lock Eleven", "05", "Yukimiya Kenyu", "FW");
            sepakbola.Rows.Add("Japan", "Blue Lock Eleven", "06", "Kenyu Yukimiya", "FW");
            sepakbola.Rows.Add("Japan", "Blue Lock Eleven", "07", "Seisho Nagi", "GK");
            sepakbola.Rows.Add("Japan", "Blue Lock Eleven", "08", "Meguru Bachira", "FW");
            sepakbola.Rows.Add("Japan", "Blue Lock Eleven", "09", "Eita Otoya", "FW");
            sepakbola.Rows.Add("Japan", "Blue Lock Eleven", "10", "RIn Itoshi", "FW");
            sepakbola.Rows.Add("Japan", "Blue Lock Eleven", "11", "Yoichi Isagi", "FW");
            sepakbola.Rows.Add("Brazil", "Brazil FC", "01", "Bento", "Gk");
            sepakbola.Rows.Add("Brazil", "Brazil FC", "02", "Leo Jardim", "Gk");
            sepakbola.Rows.Add("Brazil", "Brazil FC", "03", "Rafael", "Gk");
            sepakbola.Rows.Add("Brazil", "Brazil FC", "04", "Danilo", "DF");
            sepakbola.Rows.Add("Brazil", "Brazil FC", "05", "Ayrton Lucas", "DF");
            sepakbola.Rows.Add("Brazil", "Brazil FC", "06", "Yan Cuoto", "DF");
            sepakbola.Rows.Add("Brazil", "Brazil FC", "07", "Casemiro", "MF");
            sepakbola.Rows.Add("Brazil", "Brazil FC", "08", "Andre", "MF");
            sepakbola.Rows.Add("Brazil", "Brazil FC", "09", "Endrick", "FW");
            sepakbola.Rows.Add("Brazil", "Brazil FC", "10", "Galem=no", "FW");
            sepakbola.Rows.Add("Brazil", "Brazil FC", "11", "Savio", "FW");
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            if(lbx_player.Items.Count == 0)
            {
                MessageBox.Show("Listbox harus ada isinya", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(lbx_player.Items.Count <= 11)
            {
                MessageBox.Show("Tidak bisa kurang dari 11 pemain","Peringatan",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                lbx_player.Items.RemoveAt(lbx_player.SelectedIndex);
            }
        }
        private void combo_country_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < sepakbola.Rows.Count; i++)
            {
                if (!combo_country.Items.Contains(sepakbola.Rows[i][0]))
                {
                    combo_country.Items.Add(sepakbola.Rows[i][0]);
                }
            }

        }
        private void combo_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            combo_team.Items.Clear();
            for(int i =  0; i < sepakbola.Rows.Count;i++)
            {
                if (sepakbola.Rows[i][0] == combo_country.SelectedItem )
                {
                    if (!combo_team.Items.Contains(sepakbola.Rows[i][1]))
                    {
                        combo_team.Items.Add(sepakbola.Rows[i][1]);
                    }
                }
                else 
                {
                    combo_team.Text = null;
                }
            }
        }

        private void combo_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbx_player.Items.Clear();
            for (int i = 0;i <  sepakbola.Rows.Count; i++)
            {
                if (sepakbola.Rows[i][1] == combo_team.SelectedItem)
                {
                    lbx_player.Items.Add($"({sepakbola.Rows[i][2]}) {sepakbola.Rows[i][3]},{sepakbola.Rows[i][4]} ");
                }
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            foreach(DataRow dt in sepakbola.Rows)
            {
                if (dt["Team"].ToString() == txt_teamname.Text)
                {
                    MessageBox.Show("Tim Sudah ada", "peringatan", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cek_Team = true;
                    break;
                }
            }    
            if(cek_Team == false)
            {
                if (txt_country.Text == "" || txt_teamname.Text == "" || txt_city.Text == "")
                {
                    MessageBox.Show("semua harus keisi", "peringatan", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (txt_country.Text != null || txt_teamname.Text != null || txt_city.Text != null)
                {
                    sepakbola.Rows.Add($"{txt_country.Text}", $"{txt_teamname.Text}");
                }
            }
            txt_city.Clear();
            txt_country.Clear();
            txt_teamname.Clear();
        }

        private void btn_add2_Click(object sender, EventArgs e)
        {
            if(txt_pemain.Text == null || txt_nomor.Text == null|| combo_posisi.SelectedItem == null) 
            {
                MessageBox.Show("Harus diisi semua");
            }
            else
            {
                
                foreach (DataRow dt in sepakbola.Rows)
                {
                    if (dt["Team"].ToString() == combo_team.SelectedItem && dt["Nomor"].ToString() == txt_nomor.Text)
                    {
                        MessageBox.Show("Ada pemain dengan nomor yang sama", "peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        cek_No = true;
                    }

                }

                if(cek_No == false)
                {
                    sepakbola.Rows.Add(combo_country.SelectedItem, combo_team.SelectedItem, txt_nomor.Text, txt_pemain.Text, combo_posisi.Text);
                    lbx_player.Items.Clear();
                    for (int i = 0; i < sepakbola.Rows.Count; i++)
                    {

                        if (sepakbola.Rows[i][1] == combo_team.SelectedItem)
                        {
                            lbx_player.Items.Add($"({sepakbola.Rows[i][2]}) {sepakbola.Rows[i][3]}, {sepakbola.Rows[i][4]}");
                        }

                    }
                }
                txt_pemain.Clear();
                txt_nomor.Clear();
                
                
            }
            
        }

       
    }
}
